import sys
import os
import swango as SWANGO
import logger as logger
import xbmc
import xbmcaddon
import xbmcvfs
from contextlib import contextmanager

ADDON = xbmcaddon.Addon()


@contextmanager
def busy_dialog():
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        yield
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')


def notify(text, error=False):
        icon = 'DefaultIconError.png' if error else ''
        try:
            text = text.encode("utf-8") if type(text) is unicode else text
            xbmc.executebuiltin('Notification("%s","%s",5000,%s)' % (ADDON.getAddonInfo('name').encode("utf-8"), text, icon))
        except NameError as e:
            xbmc.executebuiltin('Notification("%s","%s",5000,%s)' % (ADDON.getAddonInfo('name'), text, icon))

def refresh():
    #xbmc.executebuiltin( "ActivateWindow(busydialognocancel)" )
    with busy_dialog():
        update()
    #xbmc.executebuiltin( "Dialog.Close(busydialognocancel)" )
    ADDON.openSettings()


def update():
    result =-1
    try:
        logger.log('Update started')
        _generate_playlist = 'true' == ADDON.getSetting("generate_playlist")
        _generate_epg = 'true' == ADDON.getSetting("generate_epg")                           
        _username_ = ADDON.getSetting("username")
        _password_ = ADDON.getSetting("password")
        _device_token_ = ADDON.getSetting("device_token")
        _device_type_code_ = ADDON.getSetting("device_type_code")
        _device_model_ = ADDON.getSetting("device_model")
        _device_name_ = ADDON.getSetting("device_name")
        _device_serial_number_ = ADDON.getSetting("device_serial_number")
        _epghourspast_ = 24* int(ADDON.getSetting("epgdays.past"))
        
        if _epghourspast_<24:
            _epghourspast_=24
        _epghourssfuture_ = 24*int(ADDON.getSetting("epgdays.future"))
        if _epghourssfuture_<24:
            _epghourssfuture_=24
        _epgpath_ = os.path.join(ADDON.getSetting("epgpath"),ADDON.getSetting("epgfile"))
        _playlistpath_ = os.path.join(ADDON.getSetting("playlistpath"),ADDON.getSetting("playlistfile"))
        _datapath_ = xbmcvfs.translatePath(ADDON.getAddonInfo('profile')) 
        _epg_lang_ = ADDON.getSetting("epg_lang")
        
        _swango_=SWANGO.SWANGO(username=_username_, password=_password_,device_token=_device_token_,device_type_code=_device_type_code_,model=_device_model_,name=_device_name_,serial_number=_device_serial_number_,datapath=_datapath_,epg_lang=_epg_lang_)
        
        if _swango_.logdevicestartup() ==True:
            _swango_.save_swango_jsons(hourspast=_epghourspast_,hoursfuture=_epghourssfuture_)
            if _generate_playlist:
                _swango_.generateplaylist(playlistpath=_playlistpath_)
            if _generate_epg:
                _swango_.generateepg(epgpath=_epgpath_,hourspast=_epghourspast_,hoursfuture=_epghourssfuture_)
            result=1
        else:
            logger.logDbg('pairing device')
            _swango_.device_token=_swango_.pairingdevice()
            logger.logDbg("Device token: " +_swango_.device_token)
            ADDON.setSetting("device_token",_swango_.device_token)
            if _swango_.logdevicestartup() ==True:
                ADDON.setSetting("device_token",_swango_.device_token)
                _swango_.save_swango_jsons(hourspast=_epghourspast_,hoursfuture=_epghourssfuture_)
                if _generate_playlist:
                    _swango_.generateplaylist(playlistpath=_playlistpath_)
                if _generate_epg:
                    _swango_.generateepg(epgpath=_epgpath_,hourspast=_epghourspast_,hoursfuture=_epghourssfuture_)
                result=1
        
    except SWANGO.UserNotDefinedException as e:
        logger.logErr(ADDON.getLocalizedString(e.id))
        notify(ADDON.getLocalizedString(e.id), True)
    except SWANGO.UserInvalidException as e:
        logger.logErr(ADDON.getLocalizedString(e.id))
        notify(ADDON.getLocalizedString(e.id), True)
    except SWANGO.TooManyDevicesException as e:
        logger.logErr(ADDON.getLocalizedString(e.id))
        notify(ADDON.getLocalizedString(e.id), True)
    except SWANGO.PairingException as e:
        logger.logErr(ADDON.getLocalizedString(e.id))
        notify(ADDON.getLocalizedString(e.id), True)
    except SWANGO.SwanGoException as e:
        logger.logErr(ADDON.getLocalizedString(e.id))
        notify(ADDON.getLocalizedString(e.id), True)

    logger.log('Update ended')
    return result

if len(sys.argv) > 1:
    if sys.argv[1] == 'refresh':
        refresh()



