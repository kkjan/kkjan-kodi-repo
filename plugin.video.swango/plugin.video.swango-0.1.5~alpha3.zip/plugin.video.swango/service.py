import datetime
import time
import requests
from  resources.lib.swango import SwanGoException
import resources.lib.logger as logger
import xbmc
import xbmcaddon
from resources.lib.functions import *



class swangoMonitor(xbmc.Monitor):
    _addon = None
    _next_update = 0
    _scriptname = None

    def __init__(self):
        xbmc.Monitor.__init__(self)
        self._addon = xbmcaddon.Addon()
        self._scriptname = self._addon.getAddonInfo('name')
        ts = self._addon.getSetting('next_update')
        self._next_update = datetime.datetime.now() if ts == '' else datetime.datetime.fromtimestamp(float(ts))
        logger.logDbg("Get settings next_update")
        self._updt_interval=int(self._addon.getSetting('update_interval'))
    
    def __del__(self):
        logger.log('service destroyed')

    def onSettingsChanged(self):
        self._addon = xbmcaddon.Addon()  # refresh for updated settings!
        notify(self._addon.getLocalizedString(30703),False)
        if not self.abortRequested():
            try:
                self._updt_interval=int(self._addon.getSetting('update_interval'))
                logger.logDbg("Setting changed")
    
                res = update()
                if res == 1:
                    notify(self._addon.getLocalizedString(30701),False)
                    self.schedule_next(self._updt_interval * 60 * 60)
                else:
                    self._addon.openSettings();
            except SwanGoException as e:
                logger.logErr(e.detail)
                notify(self._addon.getLocalizedString(e.id), True)

    def schedule_next(self, seconds):
        dt = datetime.datetime.now() + datetime.timedelta(seconds=seconds)
        logger.log('Next update %s' % dt)
        self._next_update = dt

   

    def tick(self):
        if datetime.datetime.now() > self._next_update:
            try:
                self.schedule_next(self._updt_interval * 60 * 60)
                res=update()
                if res==1:
                    notify(self._addon.getLocalizedString(30702),False)
                else:
                    self._addon.openSettings()
            except requests.exceptions.ConnectionError:
                self.schedule_next(60)
                logger.log('Can''t update, no internet connection')
                pass
            except SwanGoException as e:
                logger.logErr(e.detail)
                notify("Unexpected error", True)

    def save(self):
        self._addon.setSetting('next_update', str(time.mktime(self._next_update.timetuple())))
        logger.log('Saving next update %s' % self._next_update)


if __name__ == '__main__':
    monitor = swangoMonitor()
    
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            monitor.save()
            break
        #monitor.tick()
