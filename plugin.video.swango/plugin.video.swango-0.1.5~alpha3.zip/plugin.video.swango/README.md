Plugin for generate playlist and EPG XMLTv list for SwanGO service

Video addon lay live stream from SwanGO serevice

This plugin can be installed from repo (https://github.com/kkjan/kkjan-kodi-repo) or by zip file from https://github.com/kkjan/kkjan-kodi-repo/plugin.video.swango