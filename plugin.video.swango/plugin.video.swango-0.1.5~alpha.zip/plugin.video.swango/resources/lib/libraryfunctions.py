import sys
import xbmcgui

def update():
     xbmcgui.Dialog().ok(heading="Not implemented yet", message="Not implemented yet")

if len(sys.argv) > 1:
    if sys.argv[1] == 'update':
        update()



