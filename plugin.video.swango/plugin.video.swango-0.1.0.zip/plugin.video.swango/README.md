Plugin for generate playlist and EPG XMLTv list for SwanGO service

Video addon lay live stream from SwanGO serevice

This plugin can be installed from repo () or by zip file from 