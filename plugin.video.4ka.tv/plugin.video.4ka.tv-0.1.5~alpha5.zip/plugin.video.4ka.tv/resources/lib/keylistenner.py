import xbmcgui
from resources.lib.logger import *
class KeyListener(xbmcgui.WindowDialog):
    
    def __init__(self):
        self.key = None
      

    def onInit(self):
        """initialisation"""
        logDbg("OnInit")

    def onAction(self,action):
        code = action.getButtonCode()
        logDbg("OnAction")
        self.key = None if code == 0 else str(code)
        self.key = str(self.key)
        #conditions
        self.close()

