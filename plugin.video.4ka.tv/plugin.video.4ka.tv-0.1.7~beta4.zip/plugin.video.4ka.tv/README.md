## plugin.video.4ka

Plugin generate playlist and EPG XMLTv file for 4KA TV service. These files can by used in IPTV Simple
Plugin suport archive and record live or download  from archive.

For recording is needed install ffmpeg (https://ffmpeg.org) and select recording foler.

This plugin can be installed from repo (https://github.com/kkjan/kkjan-kodi-repo) or by zip file from https://github.com/kkjan/kkjan-kodi-repo/plugin.video.plugin.video.4ka.tv